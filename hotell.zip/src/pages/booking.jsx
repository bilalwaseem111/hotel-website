import React, { useState } from 'react';
import Link from 'next/link';
import '/styles/booking.css';


const Booking = () => {
  const [showNotification, setShowNotification] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent form from refreshing the page
    setShowNotification(true); // Show the notification
    setTimeout(() => setShowNotification(false), 5000); // Hide after 5 seconds
  };

  return (
    <div className="booking-container">
      <div className="booking-card">
        <h2 className="booking-title">Book Your Stay</h2>
        <form className="booking-form" onSubmit={handleSubmit}>
          <input type="text" placeholder="Full Name" required />
          <input type="email" placeholder="Email Address" required />
          <input type="tel" placeholder="Phone Number" required />
          <input type="date" placeholder="Check-in Date" required />
          <input type="date" placeholder="Check-out Date" required />
          <select required>
          <option value="">Select Room Type</option>
<option value="Deluxe">Deluxe Room</option>
<option value="Suite">Luxury Suite</option>
<option value="Budget">Budget Room</option>
<option value="Executive">Executive Room</option>
<option value="Presidential">Presidential Suite</option>
<option value="Family">Family Room</option>
<option value="Standard">Standard Room</option>
<option value="Superior">Superior Room</option>
<option value="Penthouse">Penthouse Suite</option>
<option value="Villa">Private Villa</option>
<option value="OceanView">Ocean View Room</option>
<option value="GardenView">Garden View Room</option>
<option value="Single">Single Room</option>
<option value="Double">Double Room</option>
<option value="Twin">Twin Room</option>
<option value="Studio">Studio Suite</option>
<option value="Loft">Loft Suite</option>
<option value="Skyline">Skyline Room</option>
<option value="King">King Room</option>
<option value="Queen">Queen Room</option>
            
          </select>
          <textarea placeholder="Special Requests (Optional)" rows="4" />
          
          <div className="payment-method">
            <h3>Payment Method</h3>
            <div className="payment-options">
              <label>
                <input type="radio" name="payment" value="credit" /> Credit Card
              </label>
              <label>
                <input type="radio" name="payment" value="paypal" /> PayPal
              </label>
            </div>
          </div>

          <button type="submit" className="submit-btn">Confirm Booking</button>
        </form>

        {/* Notification */}
        {showNotification && (
          <div className="notification">
            Your room is successfully booked!
          </div>
        )}

        <Link href="/">
          <button className="back-home-btn">Back to Home</button>
        </Link>
      </div>
    </div>
  );
};

export default Booking;
