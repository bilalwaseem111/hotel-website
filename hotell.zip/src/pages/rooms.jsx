import React from 'react';
import Link from 'next/link';
import '../styles/rooms.css';

const roomDetails = [
  { image: 'room.jpg', name: 'Deluxe Room', price: '$120/night' },
  { image: 'luxuryroom.jpg', name: 'Luxury Suite', price: '$250/night' },
  { image: 'infinity.jpg', name: 'Infinity View Suite', price: '$300/night' },
  { image: 'service.jpg', name: 'Premium Service Room', price: '$180/night' },
  { image: 'spa.jpg', name: 'Royal Spa Room', price: '$220/night' },
  { image: '12.jpg', name: 'Executive Stay Deluxe', price: '$200/night' },
  { image: 'hotel2.jpg', name: 'Garden View Retreat', price: '$190/night' },
  { image: '19.jpg', name: 'Classic Heritage Suite', price: '$160/night' },
  { image: '20.jpg', name: 'Modern Classic Elegance', price: '$170/night' },
  { image: '13.jpg', name: 'Urban Comfort King', price: '$155/night' },
  { image: 'dining.jpg', name: 'Dining Experience Suite', price: '$210/night' },
  { image: 'hotelpool.jpg', name: 'Poolside Paradise', price: '$260/night' },
  { image: 'hotel1.jpg', name: 'City View Executive', price: '$185/night' },
  { image: 'hotel2.jpg', name: 'Twin Luxury Retreat', price: '$195/night' },
  { image: '50.jpg', name: 'Cozy Budget Room', price: '$105/night' },
  { image: '51.jpg', name: 'Simple Stay Room', price: '$100/night' },
  { image: '52.jpg', name: 'Essential Comfort Room', price: '$98/night' },
  { image: 'comfy.jpg', name: 'Comfy Corner Suite', price: '$115/night' },
  { image: 'gold.jpg', name: 'Golden Touch Room', price: '$130/night' },
  { image: 'honeymoon room.jpg', name: 'Honeymoon Bliss Suite', price: '$275/night' },
];


const Rooms = () => {
  return (
    <div className="rooms-page">
      <div className="header-container">
        <h1 className="rooms-heading">Explore Our Luxurious Rooms</h1>
        <Link href="/">
          <button className="back-home-btn">Back to Home</button>
        </Link>
      </div>
      <div className="room-gallery">
  {roomDetails.map((room, index) => (
    <div className="room-card" key={index}>
      <img src={`/Images/${room.image}`} alt={room.name} className="room-image" />
      <div className="room-info">
        <h3>{room.name}</h3>
        <p className="price">{room.price}</p>
        <Link href="/booking">
          <button className="book-btn">Book Now</button>
        </Link>
      </div>
    </div>
  ))}
</div>

      <footer className="footer">
        <p>&copy; 2025 Paradise Hotel. All rights reserved.</p>
        <p>Made by Bilal Waseem</p>
      </footer>
    </div>
  );
};

export default Rooms;
